# -*- coding: utf-8 -*-

import os
import ast

def analyze_project(path):
    py_files = []
    total_lines = 0
    total_classes = 0
    total_functions = 0

    # 遍历项目目录，收集所有的.py文件
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith('.py'):
                filepath = os.path.join(root, file)
                py_files.append(filepath)

    # 分析每个.py文件
    for file in py_files:
        with open(file, 'r', encoding='utf-8') as f:
            code = f.read()
            # 统计代码总行数
            total_lines += len(code.splitlines())

            # 使用ast模块解析Python源码
            try:
                tree = ast.parse(code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        total_classes += 1
                    elif isinstance(node, ast.FunctionDef):
                        total_functions += 1
            except SyntaxError:
                print(f"无法解析文件：{file}，可能存在语法错误。")

    num_py_files = len(py_files)
    total_apis = total_classes + total_functions

    print(f"项目中.py文件的数量：{num_py_files}")
    print(f"API总数（类和函数的总数）：{total_apis}")
    print(f"代码总行数：{total_lines}")
    print(f"类的总数：{total_classes}")
    print(f"函数的总数：{total_functions}")

if __name__ == '__main__':
    project_path = "D:\postgradute_Learning\paper\exam\MuTAP-master-myself-plus\HumanEval\Testing_HumanEval\sty-master\item"
    analyze_project(project_path)
