# -*- coding: utf-8 -*-
import os

def count_asserts_in_files(path):
    total_count = 0
    for root, dirs, files in os.walk(path):
        for filename in files:
            if filename.endswith('_merge_all.py'):
                file_path = os.path.join(root, filename)
                with open(file_path, 'r', encoding='utf-8',errors='ignore') as f:
                    content = f.read()
                    count = content.count('assert')
                    total_count += count
    return total_count

if __name__ == "__main__":
    path = "D:\postgradute_Learning\paper\exam\MuTAP-master-myself-plus\HumanEval\item\\apimd-master_test\Code_Unit"
    total_asserts = count_asserts_in_files(path)
    print(f"所有以 '_merge_all.py' 结尾的文件中 'assert' 出现的总次数是: {total_asserts}")
