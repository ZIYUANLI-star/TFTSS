# -*- coding: utf-8 -*-
import itertools
import os
import re
import subprocess

import openai





def caculate_assert(file_path):  # function_to_correct，该参数是包含要检查和修正的函数代码的字符串。
    total_assert=0
    error_assert=0

    with open(file_path, encoding='utf-8',errors='ignore') as input_file:
        function_to_correct = input_file.read()

    if not os.path.exists(os.path.join(os.getcwd(), "temp_dir")):
        os.mkdir(os.path.join(os.getcwd(), "temp_dir"))


    temp_dir_path = os.path.join(os.getcwd(),
                                 "temp_dir",
                                 )

    assert_dic = []
    output = function_to_correct.split("def test():")
    code = output[0]


    '''
    作用： 尝试提取测试部分，并去除前导空格。如果没有测试部分，捕获 IndexError 异常，并返回代码部分以及两个零。
    解释： 使用 lstrip 去除前导空格，如果 split 没有分割出测试部分，将引发 IndexError。
    '''
    try:
        no_space = output[1].lstrip()  # 使用 lstrip 去除前导空格，如果 split 没有分割出测试部分，将引发 IndexError。
    except IndexError:
        print("no test")
        return 0, 0

    '''
    作用： 将测试部分按行分割成列表 assert_lst，并在第一行前添加四个空格缩进。
    解释： 使用 split("\n") 方法按行分割测试部分，并为第一行添加缩进。
    '''
    assert_lst = no_space.split("\n")
    assert_lst[0] = "    " + assert_lst[0]

    # 处理每个断言语句
    '''
    遍历 assert_lst，去除每行前导空格，并检查是否以 assert 开头
    使用 lstrip(' ') 去除每行的前导空格，使用 startswith("assert") 检查断言语句。
    '''



    # 用于保存代码片段的列表
    code_segments = []


    if_pass_assert = 0
    for ln, next_ln in zip(assert_lst, itertools.islice(assert_lst, 1, None)):
        ln = ln.lstrip(' ')
        next_ln=next_ln.lstrip(' ')
        if ln.startswith("assert"):
            code_segments.append(ln)
            '''
            作用： 构建包含代码和断言语句的临时测试代码 code_to_test，并打印。
            解释： 将代码部分和断言语句拼接成完整的临时测试代码。
            '''
            if_pass_assert = if_pass_assert + 1
            code_to_test = "# -*- coding: gbk -*-" + "\n" +code + "\n".join(code_segments)

            if next_ln.startswith("assert"):
                code_segments.pop()
            else:
                code_segments.clear()



            # temp_code_segements = ' '.join(code_segments)
            # temp_test = get_code_to_test(temp_code_segements, ln)
            # temp_test = extract_code_from_text(temp_test)
            # code_to_test = "# -*- coding: gbk -*-" + "\n" + code + '\n' + temp_test + '\n'
            #print(code_to_test)

            temp_test_script = open(
                file=os.path.join(
                    temp_dir_path,
                    "temp_test_script.py",
                ),
                mode="w",
            )
            '''
            作用： 将临时测试代码写入文件，并关闭文件。
            解释： 使用 write 方法写入代码，并显式关闭文件。
            '''
            temp_test_script.write(code_to_test)
            temp_test_script.close()

            '''
            作用： 使用 subprocess.run 运行临时测试脚本，并捕获其输出和错误信息。
            解释： 使用 subprocess.run 方法运行脚本，设置 stdout 和 stderr 捕获输出和错误，设置超时时间为 10 秒。
            '''
            try:
                result = subprocess.run(
                    [
                        "python",
                        f"{os.path.join(temp_dir_path, 'temp_test_script.py')}"
                    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, stdin=subprocess.DEVNULL
                )
                #print(result.returncode)

                # return code 0 means that the script ran without any errors
                if result.returncode == 0:
                    #print("run with no error")
                    assert_dic.append(0)
                elif result.returncode == 1:
                    # print(result.stderr.decode("utf-8"))
                    try:
                        # 尝试使用 UTF-8 解码
                        stderr_output = result.stderr.decode("utf-8")
                    except UnicodeDecodeError:
                        # 如果解码失败，使用 GBK 编码
                        stderr_output = result.stderr.decode("gbk", errors='ignore')  # 或 'replace' 替换无法解码的字符

                    # 判断是否包含 "AssertionError"
                    if "AssertionError" in stderr_output:
                        assert_dic.append(1)
                    else:
                        #print("other error")
                        assert_dic.append(2)
                else:
                    #print("Unexpected return code:", result.returncode)
                    assert_dic.append(2)

            # 作用： 捕获脚本运行超时异常，记录为 3 并打印异常信息。解释： 使用 except 捕获 TimeoutExpired 异常，记录并打印

            except subprocess.TimeoutExpired as e:
                #print("run time error")
                assert_dic.append(2)
                print(e)




        # elif ln.strip() == "" or ln.strip().startswith(('def ', 'class ')):
        #     # 忽略空行
        #     continue
        # 作用： 如果行不以 assert 开头，打印 no assert。解释： 遍历的行不是断言语句时，打印提示
        else:
            # if (if_pass_assert != 0):
            #     # 每个 assert 处理完毕后清空代码片段
            #     code_segments.clear()
            #     if_pass_assert = 0
            #     code_segments.append(ln)
            # else:
            #     code_segments.append(ln)
            code_segments.append(ln)


    for i, item in enumerate(assert_dic):
        # 断言正确，将对应的断言行添加到 final_test 中，assert_lst[i]第i个断言内容
        if item == 0:
            total_assert=total_assert+1


        # 如果 item_test 为 1表示断言语义错误
        elif item == 1:

            continue

        else:
            total_assert=total_assert+1
            error_assert=error_assert+1


    return total_assert, error_assert


def calculate_coverage_for_files(path):
    i = 0
    total_assert = 0
    error_assert = 0

    for root, dirs, files in os.walk(path):
        for filename in files:
            if filename.endswith('_merge_all.py'):
                print(f"Processing file {i}: {filename}")
                i += 1
                file_path = os.path.join(root, filename)
                temp_total_assert, temp_error_assert = caculate_assert(file_path)
                total_assert=total_assert+temp_total_assert
                error_assert=error_assert+temp_error_assert
                print(f"total_assert: {total_assert}")
                print(f"error_assert: {error_assert}")



if __name__ == "__main__":
    path = r"D:\postgradute_Learning\paper\exam\MuTAP-master-myself-plus\HumanEval\Testing_HumanEval"
    calculate_coverage_for_files(path)
