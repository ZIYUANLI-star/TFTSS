# Code of Conduct

## Goal

Our goal is to make the world a better place. We invite everyone.

## Expected Behavior

Do whatever you want to achieve our goal. Just mind the consequences.

## Unacceptable Behavior

Do not be an asshole.

Please, also take a notice that different people
understand unacceptable behavior differently.

## Consequences of Unacceptable Behavior

It depends:

1. Nothing may happen
2. People can tell you that you are an asshole
3. People can apply any administrative regulations that they find acceptable for your behavior
4. People can beat the shit out of you
5. You can get arrested if you violate the law while being an asshole

## Addressing Grievances

Just deal it with.
You can also accuse another party at being more asshole than you if that's actually true.

## Scope

It applies to your whole life.

## About this Code of Conduct 
This Code of Conduct was brazenly stolen from [Moscow Python Beer Meetup](https://github.com/moscow-python-beer/moscow-code-of-conduct), but shhh they don't know about it.
