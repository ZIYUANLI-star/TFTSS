# Authors and Contributors

`codetiming` is written and maintained by the [Real Python team](https://realpython.com/team/).


## Author and Maintainer

- [Geir Arne Hjelle](https://github.com/gahjelle)


## Contributors

- [Alkatar21](https://github.com/alkatar21)
- [D.C. Hess](https://github.com/dchess)
- [Jan Freyberg](https://github.com/janfreyberg)
- [Mischa Lisovyi](https://github.com/mlisovyi)
- [Matthew Price](https://github.com/pricemg)

See the [changelog](https://github.com/realpython/codetiming/blob/master/CHANGELOG.md) for more details.
